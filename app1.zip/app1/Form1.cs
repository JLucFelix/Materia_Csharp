namespace app1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Visible = false;
            label4.Visible = false;
            axWindowsMediaPlayer1.Visible = false;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string txtDatanascimento = textBox2.Text;
            string txtNome = textBox1.Text;

            DateTime dataNascimento;
            if (DateTime.TryParse(txtDatanascimento, out dataNascimento))
            {
                DateTime hoje = DateTime.Today;
                int idade = hoje.Year - dataNascimento.Year;

                if (hoje < dataNascimento.AddYears(idade))
                {
                    idade--;
                }

                label2.Text = $"Bem vindo {txtNome}, sua data de nascimento � {txtDatanascimento} e sua idade � {idade} anos.";
                label2.Font = new Font("Arial", 12f);
            }
            else
            {
                label2.Text = "Data de nascimento inv�lida!";
                label2.Font = new Font("Arial", 12f);
            }
            pictureBox1.Visible = true;
            label4.Text = "O RAT�O";
            label4.Visible = true;
            axWindowsMediaPlayer1.URL = @"C:\Users\Aluno\Downloads\Carly Rae Jepsen - Call Me Maybe (Lyrics).mp3";
            axWindowsMediaPlayer1.Ctlcontrols.play(); // Iniciar a reprodu��o
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
