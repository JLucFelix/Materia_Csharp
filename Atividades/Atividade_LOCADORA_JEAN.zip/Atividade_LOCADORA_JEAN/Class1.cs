﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Filme
    {
        public string Titulo { get; set; }
        public string Genero { get; set; }
        public int Unidades { get; set; }
        public Filme(string titulo, string genero, int unidades)
        {
            Titulo = titulo;
            Genero = genero;
            Unidades = unidades;
        }

    }
    public class Cliente
    {
        public string Nome { get; set; }
        public List<Filme> Filmes { get; set; } = new List<Filme>();

        public Cliente(string nome)
        {
            Nome = nome;
        }
        public void AdicionarFilme(Filme filme)
        {
            Filmes.Add(filme);
        }
    }
    public class Locacao
    {
        Cliente cliente { get; set; }
        Filme filme { get; set; }
        public Locacao(Cliente cliente, Filme filme)
        {
            if (filme.Unidades <= 0)
            {
                throw new Exception("Quantidade maior que a disponível");
            }
            filme.Unidades--;
            cliente.Filmes.Add(filme);

            Console.WriteLine($"Locação realizada com sucesso!");
            Console.WriteLine($"- Filme: {filme.Titulo} ({filme.Genero})");
            Console.WriteLine($"- Cliente: {cliente.Nome}");
            Console.WriteLine($"- Unidades restantes: {filme.Unidades}");
        }


    }
}
