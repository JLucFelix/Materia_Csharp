﻿using Classes;
namespace Atividade_LOCADORA_JEAN
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cliente cliente1 = new Cliente("Jean Lucas");
            Filme filme1 = new Filme("Senhor dos aneis", "Fantasia", 2);
            cliente1.AdicionarFilme(filme1);
            Locacao locacao1 = new Locacao(cliente1, filme1);
        }
    }
}
