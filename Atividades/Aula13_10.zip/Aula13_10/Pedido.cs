﻿using Aula13_10;
using System;
using System.Collections.Generic;
using System.Linq; 

internal class Pedido
{
    public Guid NumeroPedido { get; set; }

    public List<Produto> Itens { get; private set; }

    public double ValorTotal { get; private set; }

    public Pedido()
    {
        NumeroPedido = Guid.NewGuid();
        Itens = new List<Produto>();
    }

    public void AdicionarItem(Produto produto)
    {
        Itens.Add(produto);
        CalcularValorTotal();
    }

    public void RemoverItem(Produto produto)
    {
        Itens.Remove(produto);
        CalcularValorTotal();
    }

    private void CalcularValorTotal()
    {
        ValorTotal = Itens.Sum(item => item.Preco);
    }

    public string ExibirResumo()
    {
        string resumo = $"Resumo do pedido ID: {NumeroPedido}\n";
        resumo += "Itens:\n";
        foreach (var item in Itens)
        {
            resumo += $"- {item.Nome} (R$ {item.Preco:F2}) Estoque {item.Estoque}\n";
        }
        resumo += $"Valor Final: R$ {ValorTotal:F2}";
        return resumo;
    }
}