﻿namespace Aula13_10
{
    class Program
    {
        static void Main(string[] args)
        {
            Pedido pedido1 = new Pedido();
            
            Produto produto1 = new Produto("Banana", 12.50, 2);
            pedido1.AdicionarItem(produto1);
            Console.WriteLine(pedido1.ExibirResumo());

            Produto produto2 = new Produto("Chocolate", 42.50, 10);
            
            pedido1.AdicionarItem(produto2);

            Console.WriteLine(pedido1.ExibirResumo());

            pedido1.RemoverItem(produto2);
            Console.WriteLine(pedido1.ExibirResumo());
        }
    }
}
