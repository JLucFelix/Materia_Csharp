﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Aula13_10
{
    internal class Produto
    {
        public int Estoque { get; private set; }
        public double Preco { get; private set; }
        public string Nome { get; set; }

        public Produto(string nome, double preco, int estoque)
        {
            if (preco < 0)
            {
                throw new ArgumentException("O preço não pode ser negativo.", nameof(preco));
            }
            if (estoque < 0)
            {
                throw new ArgumentException("O estoque não pode ser negativo.", nameof(estoque));
            }
            Nome = nome;
            Preco = preco;
            Estoque = estoque;
        }

        public int ObterEstoque()
        {
            return Estoque;
        }
        public void AtualizarPreco(double novo_preco)
        {
            Preco = novo_preco;
        }
        public void Vender(int quantidade)
        {
            Estoque -= quantidade;
        }
    }
}
