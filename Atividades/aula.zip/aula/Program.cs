﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.ComponentModel;
namespace aula
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> exercicio1 = new List<string>();
            List<string> exercicio2 = new List<string>();
            List<string> exercicio3 = new List<string>();
            List<string> exercicio4 = new List<string>();
            List<double> exercicio5 = new List<double>();
            Console.WriteLine("\nExercicio 1\n");
            //Exercicio 1
            TextReader reader = new StreamReader("nomes_telefones.txt");
            string texto;
            while ((texto = reader.ReadLine()) != null )
            {
                string texto_alteracao = texto.Replace("(", " ").Replace(")", " ").Replace("-", " ");
                exercicio1.Add(texto_alteracao);
                Console.WriteLine(exercicio1[exercicio1.Count - 1]);

            }
            Console.WriteLine("\nExercicio 2\n"); 
            //Exercicio 2
            TextReader reader2 = new StreamReader("nomes_telefones.txt");
            string texto2;
            while ((texto2 = reader2.ReadLine()) != null)
            {
                string nomes = texto2.Substring(16);
                if (nomes.Length > 12)
                {
                    string nomes_upper = nomes.ToUpper();
                    exercicio2.Add(nomes_upper);
                    Console.WriteLine(exercicio2[exercicio2.Count - 1]);
                } 
            }
            Console.WriteLine("\nExercicio 3\n");
            //Exercicio 3
            TextReader reader3 = new StreamReader("datas.txt");
            string texto3;
            while ((texto3 = reader3.ReadLine()) != null) 
            { 
                string anos = texto3.Substring(6);
                exercicio3.Add(anos);
                Console.WriteLine(exercicio3[exercicio3.Count - 1]);
            }
            Console.WriteLine("\nExercicio 4\n");
            //Exercicio 4
            TextReader reader4 = new StreamReader("marcas_carros.txt");
            string texto4;
            while ((texto4 = reader4.ReadLine()) != null)
            {
                int posicao_arroba = texto4.IndexOf("@");
                string marca = texto4.Substring(0, posicao_arroba);
                exercicio4.Add(marca);
                Console.WriteLine(exercicio4[exercicio4.Count - 1]);
            }
            Console.WriteLine("\nExercicio 5\n");
            //Exercicio 5
            TextReader reader5 = new StreamReader("produtos_estoque.txt");
            string texto5;
            int somatotal_estoque = 0;
            double somatotal_real = 0;
            while ((texto5 = reader5.ReadLine()) != null)
            {
                int estoque = texto5.IndexOf("|");
                if (estoque != -1)
                {
                    string valor_total_string = texto5.Substring(estoque+1);
                    int valor_total_int = Convert.ToInt32(valor_total_string);
                    somatotal_estoque += valor_total_int;
                }
                int valor_real = texto5.IndexOf("$");
                if (valor_real != -1)
                {
                    string valor_real_string = texto5.Substring(valor_real+1, 5);
                    double valor_real_int = Convert.ToDouble(valor_real_string);
                    somatotal_real += valor_real_int;
                    
                }
            }
            exercicio5.Add(somatotal_estoque);
            exercicio5.Add(somatotal_real);
            if (exercicio5.Count > 0)
            {
                Console.WriteLine($"O valor total de estoque é {exercicio5[exercicio5.Count - 2]}");
                Console.WriteLine($"O valor total de estoque é {exercicio5[exercicio5.Count - 1]}");
            }
        }
    }
}
