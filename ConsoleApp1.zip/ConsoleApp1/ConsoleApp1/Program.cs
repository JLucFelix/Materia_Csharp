﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("Digite o valor 1");
            //Entrada de dados
            int valor1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite o valor 2");
            int valor2 = Convert.ToInt32(Console.ReadLine());

            int soma = valor2 + valor1;
            Console.WriteLine("A soma é: " + soma);

            //Exercicio 1:
            Console.WriteLine("Digite um valor ");
            int valor_impar_par = Convert.ToInt32(Console.ReadLine());
            if (valor_impar_par % 2 == 0)
            {
                Console.WriteLine("O numero "  + valor_impar_par  + "é par");
            }
            else
            {
                Console.WriteLine("O numero " + valor_impar_par  + "é impar");
            }

            //Exercicio 2:
            Console.WriteLine("Digite um valor de temperatura em Fº");
            decimal valor_fahrenheit = Convert.ToDecimal(Console.ReadLine());
            decimal valor_celsius = 5 * ((valor_fahrenheit - 32)/9);
            Console.WriteLine("A temperatura convertida é " + valor_celsius +"º");

            *///Exercicio 3:

            Console.WriteLine("Digite o valor A");
            int valor_a = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Digite o valor B");
            int valor_b = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Digite o valor C");
            int valor_c = Convert.ToInt16(Console.ReadLine());

            int delta = valor_b ^ 2 - 4 * valor_a * valor_c;
            int A1 = (int)((-valor_b + Math.Sqrt(delta)) / (2 * valor_a));
            int A2 = (int)((-valor_b - Math.Sqrt(delta)) / (2 * valor_a));
            Console.WriteLine("Valor de A1 = " + A1 + "Valor de A2 = " + A2);
            Console.ReadKey();
        }
    }
}

