using InventoryLib;
using System.Linq;
namespace WinForms
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = Microsoft.VisualBasic.Interaction.InputBox("Digite o nome do produto: ", "Nome do produto", "");
            string precostr = Microsoft.VisualBasic.Interaction.InputBox("Digite o pre�o do produto: ", "Pre�o do produto", "");

            if (double.TryParse(precostr, out double preco))
            {
                var produto = new Produto()
                {
                    Id = InventoryManager.produtos.Count + 1,
                    Name = nome,
                    Price = preco
                };
                InventoryManager.AdicionarProduto(produto);
                MessageBox.Show("Produto adicionado com sucesso!");
            }
            else
            {
                MessageBox.Show("Pre�o inv�lido. Tente novamente.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nome = Microsoft.VisualBasic.Interaction.InputBox("Digite o nome do produto a ser removido: ", "Nome do produto", "");

            var produto = InventoryManager.produtos
                .FirstOrDefault(p => p.Name != null && p.Name.Equals(nome, StringComparison.OrdinalIgnoreCase));
            if (produto != null)
            {
                InventoryManager.RemoverProduto(produto);
                MessageBox.Show("Produto removido com sucesso!");
            }
            else
            {
                MessageBox.Show("Produto n�o encontrado.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridViewProdutos.DataSource = null;
            dataGridViewProdutos.DataSource = InventoryManager.produtos.ToList();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
